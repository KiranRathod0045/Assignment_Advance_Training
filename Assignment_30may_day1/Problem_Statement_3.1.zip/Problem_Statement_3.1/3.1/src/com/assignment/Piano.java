package com.assignment;

public class Piano extends Instruments{

	public void play() {
		System.out.println("Piano is playing  tan tan tan tan");

	}
}
