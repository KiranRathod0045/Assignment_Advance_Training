package com.assignment;

public class Flute extends Instruments {

	public void play() {
		System.out.println("Flute is playing  toot toot toot toot");

	}

}
