import java.util.Scanner;

public class LinkedList {
	
	static class Node {
        int data;
        Node next;
        Node(int tmp) {data = tmp;}
    }
 
    static Node findNthNodeFromLastV1(Node head, int n) {

        int length = 0;
        Node temp = head;
        while(temp != null) {
            temp = temp.next;
            length++;
        }
        System.out.println("length: "+length);
        for(int i=0;i<length-n;i++) {
            head = head.next;
        }
        return head;
    }
 
    static Node findNthNodeFromLastV2(Node head, int n) {
 
        Node refNode = head;
        Node mainNode = head;
        if(head == null) {
            return null;
        }
        for(int i=0;i<n;i++) {
            if(refNode == null) {
                System.out.println("The n input size is more than linked list size");
                return null;
            }
            refNode = refNode.next;
        }
 
        while(refNode != null) {
            mainNode = mainNode.next;
            refNode = refNode.next;
        }
 
        return mainNode;
    }
 
    public static void main(String[] a) {

    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter head node value");
    	int headNode = sc.nextInt();
    	sc.nextLine();
    	System.out.println("Enter no of nodes");
    	int n = sc.nextInt();
    	sc.nextLine();
    	
    	
    	Node head = new Node(headNode);
    	Node prev = head;
	for(int i=0;i<n-1;i++) {
			System.out.println("Enter node value");
			int val = sc.nextInt();
			sc.nextLine();
    		Node node = new Node(val);
    		prev.next = node;
    		prev = node;
    	}

        Node nthNode = findNthNodeFromLastV2(head, 2);
        System.out.println("Nth node value: "+nthNode.data);
    }
}
